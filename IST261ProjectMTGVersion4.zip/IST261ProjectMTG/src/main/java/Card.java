/*****
 * IST 261 - M02-A02
 * Jordan Runyon - jjr6639
 * Sept. 15. 2024
 */

public class Card {
    private String name;
    private String type;
    private int manaCost;
    private int powerLevel;

    //Parameterized constructor
        public Card(String name, String type, int manaCost, int powerLevel) {
        this.name = name;
        this.type = type;
        this.manaCost = manaCost;
        this.powerLevel = powerLevel;
    }

    // Accessors andMutators
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getManaCost() {
        return manaCost;
    }

    public void setManaCost(int manaCost) {
        this.manaCost = manaCost;
    }

    public int getPowerLevel() {
        return powerLevel;
    }

    public void setPowerLevel(int powerLevel) {
        this.powerLevel = powerLevel;
    }

    //OverridetoString method
    @Override
    public String toString() {
        return "Card [name=" + name + ", type=" + type + ", manaCost=" + manaCost + ", powerLevel=" + powerLevel + "]";
    }
}
