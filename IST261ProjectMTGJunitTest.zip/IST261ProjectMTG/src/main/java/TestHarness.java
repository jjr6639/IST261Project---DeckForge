import java.util.ArrayList;

public class TestHarness {

    // Constructor in order to run tests on all model classes
    public TestHarness() {
        // Testing UserProfile class
        System.out.println("Testing the UserProfile class...");
        UserProfile profile = new UserProfile("Calvin", "Black Deck User, PA Native.");
        System.out.println("Initial UserProfile: " + profile.toString());
        profile.setDisplayName("Calvin Klein");
        profile.setBio("Magic the Gathering player and coder.");
        System.out.println("Modified UserProfile: " + profile.toString());

        // Testing the Card class
        System.out.println("\nTesting the Card class...");
        Card card1 = new Card("Lightning Bolt", "Instant", 1, 3);
        Card card2 = new Card("Dark Elves", "Creature", 1, 1);

        // Test accessors for card1
        System.out.println("Initial Card 1: " + card1.toString());
        card1.setName("Shock");
        card1.setType("Instant");
        card1.setManaCost(1);
        card1.setPowerLevel(2);
        System.out.println("Modified Card 1: " + card1.toString());

        // Test accessors for card2
        System.out.println("Initial Card 2: " + card2.toString());
        card2.setName("Forest");
        card2.setType("Land");
        card2.setManaCost(0);
        card2.setPowerLevel(0);
        System.out.println("Modified Card 2: " + card2.toString());

        // Testing the Deck class
        System.out.println("\nTesting the Deck class...");
        ArrayList<Card> cards = new ArrayList<>();
        cards.add(card1);
        cards.add(card2);

        Deck deck = new Deck("Mono-Red Aggro", "Standard", "Aggro", cards);
        System.out.println("Initial Deck: " + deck.toString());
        deck.setName("Mono-Green Ramp");
        deck.setFormat("Modern");
        deck.setMetaType("Ramp");
        System.out.println("Modified Deck: " + deck.toString());

        // Testing User class
        System.out.println("\nTesting User class...");
        ArrayList<Deck> userDecks = new ArrayList<>();
        userDecks.add(deck);

        User user = new User("calvinklein", "password123", profile, userDecks);
        System.out.println("Initial User: " + user.toString());
        user.setUsername("Cklein");
        user.setPassword("newpassword456");
        user.setProfile(new UserProfile("C. Klein", "Avid MTG player."));
        user.setDecks(new ArrayList<>());
        System.out.println("Modified User: " + user.toString());

        user.getDecks().add(deck);
        System.out.println("User after re-adding deck: " + user.toString());

        System.out.println("\nAll tests have completed successfully.");
    }

    public static void main(String[] args) {
        new TestHarness();
    }
}

