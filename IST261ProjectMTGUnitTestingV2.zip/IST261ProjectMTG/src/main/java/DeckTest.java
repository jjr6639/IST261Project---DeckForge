/***
 * Jordan Runyon - IST 261
 * Junit tests
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

 class DeckTest {
    private Deck deck;
    private Card card1;
    private Card card2;
    private List<Card> cards;

    @BeforeEach
     void setUp() {
        card1 = new Card("Lightning Bolt", "Instant", 1, 3);
        card2 = new Card("Llanowar Elves", "Creature", 1, 1);
        cards = new ArrayList<>();
        cards.add(card1);
        cards.add(card2);
        deck = new Deck("Mono-Red Aggro", "Standard", "Aggro", cards);
    }

    @Test
    void testGetName() {
        assertEquals("Mono-Red Aggro", deck.getName());
    }

    @Test
    void testSetName() {
        deck.setName("Mono-Green Ramp");
        assertEquals("Mono-Green Ramp", deck.getName());
    }

    @Test
    void testGetFormat() {
        assertEquals("Standard", deck.getFormat());
    }

    @Test
    void testSetFormat() {
        deck.setFormat("Modern");
        assertEquals("Modern", deck.getFormat());
    }

    @Test
    void testGetMetaType() {
        assertEquals("Aggro", deck.getMetaType());
    }

    @Test
    void testSetMetaType() {
        deck.setMetaType("Control");
        assertEquals("Control", deck.getMetaType());
    }

    @Test
    void testGetCards() {
        assertEquals(cards, deck.getCards());
    }

    @Test
    void testSetCards() {
        List<Card> newCards = new ArrayList<>();
        newCards.add(new Card("Forest", "Land", 0, 0));
        deck.setCards(newCards);
        assertEquals(newCards, deck.getCards());
    }

    @Test
    void testToString() {
        String expected = "Deck [name=Mono-Red Aggro, format=Standard, metaType=Aggro, cards=" + cards + "]";
        assertEquals(expected, deck.toString());
    }
}
