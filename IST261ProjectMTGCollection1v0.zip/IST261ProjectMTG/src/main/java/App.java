/**
 * jjr6639 - Jordan Runyon
 */

public class App {

        public static void main(String[] args) {
        DeckHashMap deckHashMap = new DeckHashMap();
        DeckView deckView = new DeckView();
         new DeckController(deckHashMap, deckView);
    }
}
