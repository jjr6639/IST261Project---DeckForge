/**
 * Jordan Runyon - JJR6639
 */

public class DeckController {
    private DeckHashMap deckHashMap;
    private DeckView deckView;
    public DeckController(DeckHashMap deckHashMap, DeckView deckView) {
        this.deckHashMap = deckHashMap;
        this.deckView = deckView;

        setupViewListeners();
        deckView.displayDeckList(deckHashMap.getAllDecks());
    }
    private void setupViewListeners() {
        deckView.addAddListener(e -> addDeck());
        deckView.addSearchListener(e -> searchDeck());
        deckView.addRemoveListener(e -> removeDeck());
    }

    private void addDeck() {
        String name = deckView.getNameInput();
        String format = deckView.getFormatInput();
        String metaType = deckView.getMetaTypeInput();

        Deck newDeck = new Deck(name, format, metaType, null);
        deckHashMap.addDeck(newDeck);
        deckView.displayMessage("Deck added: " + name);
        deckView.displayDeckList(deckHashMap.getAllDecks());
    }private void searchDeck() {
        String name = deckView.getSearchInput();
        Deck foundDeck = deckHashMap.getDeck(name);

        if (foundDeck != null) {
            deckView.displayDeckDetails(foundDeck);
        } else {


            deckView.displayMessage("Deck not found: " + name);
        }
    }
    private void removeDeck() {
        String name = deckView.getSearchInput();
        if (deckHashMap.getDeck(name) != null) {
            deckHashMap.removeDeck(name);
            deckView.displayMessage("Deck removed: " + name);
            deckView.displayDeckList(deckHashMap.getAllDecks());
        } else {
            deckView.displayMessage("Deck not found: " + name);
        }
    }
}
