/**
 * jjr6639 - Jordan Runyon
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class DeckView extends JFrame {
    private JTextField nameField, formatField, metaTypeField, searchField;
    private JTextArea displayArea;
    private JButton addButton, searchButton, removeButton;

    public DeckView() {
        setTitle("Deck Manager");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Format:"));
        formatField = new JTextField();
        inputPanel.add(formatField);

        inputPanel.add(new JLabel("Meta Type:"));
        metaTypeField = new JTextField();
        inputPanel.add(metaTypeField);

        addButton = new JButton("Add Deck");
        inputPanel.add(addButton);

        add(inputPanel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(new JLabel("Search by Name:"));
        searchField = new JTextField(10);
        searchPanel.add(searchField);

        searchButton = new JButton("Search");
        searchPanel.add(searchButton);

        removeButton = new JButton("Remove");
        searchPanel.add(removeButton);

        add(searchPanel, BorderLayout.CENTER);

        // Display area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        add(new JScrollPane(displayArea), BorderLayout.SOUTH);

        setVisible(true);
    }

    // Input Getters
    public String getNameInput() {
        return nameField.getText();
    }

    public String getFormatInput() {
        return formatField.getText();
    }

    public String getMetaTypeInput() {
        return metaTypeField.getText();
    }

    public String getSearchInput() {
        return searchField.getText();
    }

    // Display Methods
    public void displayMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void displayDeckList(HashMap<String, Deck> deckMap) {
        displayArea.setText("Deck List:\n");
        for (Deck deck : deckMap.values()) {
            displayArea.append(deck.getName() + "\n");
        }
    }

    public void displayDeckDetails(Deck deck) {
        displayMessage("Deck Details:\nName: " + deck.getName() + "\nFormat: " + deck.getFormat() + "\nMeta Type: " + deck.getMetaType());
    }

    // Listeners
    public void addAddListener(ActionListener listener) {
        addButton.addActionListener(listener);
    }

    public void addSearchListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public void addRemoveListener(ActionListener listener) {
        removeButton.addActionListener(listener);
    }
}
