/*****
 * IST 261 - M02-A02
 * Jordan Runyon - jjr6639
 * Sept. 15th 2024
 */

import java.io.Serializable;
import java.util.List;

public class Deck implements Serializable {
    private String name;
    private String format;
    private String metaType;
    private List<Card> cards;

    public Deck(String name, String format, String metaType, List<Card> cards) {
        this.name = name;
        this.format = format;
        this.metaType = metaType;
        this.cards = cards;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getMetaType() {
        return metaType;
    }

    public void setMetaType(String metaType) {
        this.metaType = metaType;
    }

    public List<Card> getCards() {
        return cards;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    @Override
    public String toString() {
        return "Deck{name='" + name + "', format='" + format + "', metaType='" + metaType + "', cards=" + cards + "}";
    }
}
